function myFunction2() {
    document.getElementById("sample").innerHTML = "Changed from a function in the External Script"
}

// single line comment

/* 
block comments
*/